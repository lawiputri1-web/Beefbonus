BEEF BONUS — Minecraft Java 1.21 / Fabric Loader

Setiap kali makan steak, hadiah acak diberikan. Daftar hadiah dibuat beragam:
- Makanan, buah, kue, golden apple
- Blok bangunan dan material dekorasi
- Tools dan perlengkapan
- Weapon, panah, roket
- Armor, Elytra, Wolf Armor
- Resource seperti iron/gold/diamond/emerald/ender pearl
- Utility/loot seperti name tag, saddle, shulker shell, beacon, totem
- Enchanted book dengan enchantment dan level acak
- Potion dan item langka
- Netherite ingot dan Netherite Upgrade Smithing Template sangat langka
- Jackpot super langka: netherite gear atau enchanted golden apple

Probabilitas kategori berbobot di kode; item langka memang jauh lebih jarang.
Jika inventori penuh, hadiah dijatuhkan ke tanah.

STATUS: Proyek sumber saja, belum JAR siap pasang dan belum dites. Build butuh JDK 21
serta koneksi internet ke repositori Fabric/Maven. Jalankan `gradle build` dari folder
proyek; hasil di `build/libs/beefbonus-1.0.0.jar`. Pasang Fabric Loader + Fabric API
untuk Minecraft Java 1.21.
